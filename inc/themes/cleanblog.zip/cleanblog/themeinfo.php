<?php
/*
* Name: Clean Blog Themes
* Desc: Clean Blog Themes ported from StartBootstrap.com
* Version: 0.0.1
* Build: 0.0.2
* Developer: GeniXCMS
* URI: http://www.genixcms.org
* License: MIT License
* Icon: <i class="fa fa-cogs"></i>
*/