<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GeniXCMS <?=System::v();?> Installer </title>

    <!-- Custom styles for this template -->
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
    #page-wrapper {
      margin-left: 0px!important;
    }
    </style>
  </head>
 
  <body>
    <div id="wrapper">
    <div class="header col-md-12">
      <h1><img src="assets/images/genixcms-logo-small.png" class="pull-left"> GeniXCMS <small><?=System::v();?></small><br/><small>Installer</small></h1>

    </div>


    <div id="page-wrapper">
