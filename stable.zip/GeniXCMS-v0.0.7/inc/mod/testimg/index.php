<?php
/*
* Name: TestImage CLass
* Desc: TestImage CLass description
* Version: 0.0.1
* Build: 0.0.1 pre
* Developer: Puguh Wijayanto
* URI: http://www.metalgenix.com
* License: MIT License
* Icon: <i class="fa fa-cogs"></i>
*/