<?php

class Mods
{
    public static function show() {
        echo "Mod Show";
    }
}