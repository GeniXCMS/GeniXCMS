<div class="row">
    <div class="col-md-12">
        <h1>GeniXCMS Module Sample</h1>
        <hr />
    </div>
    <div class="col-md-12">
        This is GeniXCMS Module Sample. Create your own module to make a great applications.
    </div>

</div>