<?php
/*
* Name: NewsLetter
* Desc: NewsLetter for sending Mail to Members.
* Version: 0.0.1
* Build: 0.0.2
* Developer: Puguh Wijayanto
* URI: http://www.metalgenix.com
* License: MIT License
* Icon: <i class="fa fa-envelope-o"></i>
*/