<h2><i class="fa fa-database"></i> Database Error</h2>
Something went wrong with the database.<br />
<div style="border-radius: 7px; border: 3px solid #cc0000; line-height: 35px; 
height: 50px; background-color: #aa0000; color: #fff; padding: 5px;">
<?php
echo $val;
?>
</div>