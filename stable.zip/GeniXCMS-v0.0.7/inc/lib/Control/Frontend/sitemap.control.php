<?php if(!defined('GX_LIB')) die("Direct Access Not Allowed!");
/*
*    GeniXCMS - Content Management System
*    ============================================================
*    Build          : 20140925
*    Version        : 0.0.1 pre
*    Developed By   : Puguh Wijayanto (www.metalgenix.com)
*    License        : MIT License
*    ------------------------------------------------------------
* filename : sitemap.control.php
* version : 0.0.1 pre
* build : 20141007
*/

    Sitemap::create();

/* End of file sitemap.control.php */
/* Location: ./inc/lib/Control/Frontend/sitemap.control.php */