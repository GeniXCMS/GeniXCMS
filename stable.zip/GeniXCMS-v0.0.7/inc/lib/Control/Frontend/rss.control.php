<?php if(!defined('GX_LIB')) die("Direct Access Not Allowed!");
/*
*    GeniXCMS - Content Management System
*    ============================================================
*    Build          : 20140925
*    Version        : 0.0.1 pre
*    Developed By   : Puguh Wijayanto (www.metalgenix.com)
*    License        : MIT License
*    ------------------------------------------------------------
* filename : rss.control.php
* version : 0.0.1 pre
* build : 20150131
*/

    Rss::create();

/* End of file rss.control.php */
/* Location: ./inc/lib/Control/Frontend/rss.control.php */