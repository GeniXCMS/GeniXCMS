<?php if(!defined('GX_LIB')) die("Direct Access Not Allowed!");
/**
* GeniXCMS - Content Management System
* 
* PHP Based Content Management System and Framework
*
* @package GeniXCMS
* @since 0.0.1 build date 20140925
* @version 0.0.7
* @link https://github.com/semplon/GeniXCMS
* @link http://genixcms.org
* @author Puguh Wijayanto (www.metalgenix.com)
* @copyright 2014-2015 Puguh Wijayanto
* @license http://www.opensource.org/licenses/mit-license.php MIT
*
*/

class Language
{
    public function __construct () {
        self::setActive();
    }

    public static function getList () {
        $handle = dir(GX_PATH.'/inc/lang/');
        while (false !== ($entry = $handle->read())) {
            if ($entry != "." && $entry != ".." ) {
                $file = GX_PATH.'/inc/lang/'.$entry;
                $ext = pathinfo($file, PATHINFO_EXTENSION);
                if(is_file($file) == true && $ext == 'php'){
                    $lang[] = $entry;
                } 
            }
        }
        
        $handle->close();
        return $lang;
    }

    public static function optDropdown ($var) {
        $langs =  self::getList();
        $opt = '';
        foreach ($langs as $lang) {

            $file = explode('.', $lang);
            if ($var == $file[0]) {
                $sel = 'SELECTED';
            }else{
                $sel = '';
            }
            $opt .= "<option {$sel}>{$file[0]}</option>";
        }
        return $opt;
    }

    public static function getDefaultLang() {
        $def = Options::v('multilang_default');
        $lang = json_decode(Options::v('multilang_country'), true);
        $deflang = $lang[$def];
        return $deflang;
    }

    public static function getLangParam($lang, $post_id) {
        if (Posts::existParam('multilang',$post_id)) {
            $multilang = json_decode(Posts::getParam('multilang', $post_id), true);
            // print_r(Posts::getParam('multilang', $post_id));
            foreach ($multilang as $key => $value) {
                // print_r($value);
                $keys = array_keys($value);
                // print_r($keys);
                if ($keys[0] == $lang) {
                    $lang = $multilang[$key][$lang];
                    return $lang;
                }
            }
        }
    }

    public static function setActive($lang = '') {
        if (isset($_GET['lang']) && $_GET['lang'] != '' && $lang == '') {
            Session::set(array('lang' => $_GET['lang'] ) );
        }elseif ($lang != '') {
            Session::set(array('lang' => $lang ) );
        }
    }

    public static function isActive () {
        switch (SMART_URL) {
            case true:
                if (Options::v('multilang_enable') === 'on') {
                    $langs = Session::val('lang');
                    if($langs != '') {
                        $lang = Session::val('lang');
                    }else{
                        $lang = '';
                    }
                    
                }else{
                    $lang = '';
                }
                
                break;
            
            default:
                if (Options::v('multilang_enable') === 'on') {
                    $langs = Session::val('lang');
                    if($langs != '') {
                        $lang = Session::val('lang');
                    }else{
                        $lang = isset($_GET['lang'])? $_GET['lang']: '' ;
                    }
                }else{
                    $lang = '';
                }
                break;

        }
        return $lang;
    }

    public static function flagList () {
        $lang = json_decode(Options::v('multilang_country'), true);
        // print_r($lang);
        $html = "<ul class=\"nav nav-pills\">";
        foreach ($lang as $key => $value) {
            $flag = strtolower($value['flag']);
            $html .= "
            <li class=\"\"><a href=\"".Url::flag($key)."\" class=\"flag-icon flag-icon-{$flag}\"></a></li>
            ";
        }
        $html .= "</ul>";
        Hooks::attach('footer_load_lib', array('Language', 'flagLib'));
        return $html;
    }

    public static function flagLib () {
        return "<link href=\"".Site::$url."/assets/css/flag-icon.min.css\" rel=\"stylesheet\">";
    }
}
/* End of file Language.class.php */
/* Location: ./inc/lib/Language.class.php */