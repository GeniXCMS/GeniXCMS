    </div><!-- /.row -->

    </div><!-- /.container -->
    <div class="blog-footer">
      <p>Blog template built for <a href="http://getbootstrap.com">Bootstrap</a> by <a href="https://twitter.com/mdo">@mdo</a>.</p>
      <p>Powered by <a href="http://genixcms.org" title="Free and Opensource CMS">GeniXCMS <?=System::v();?></p>
      <p>
        <a href="#">Back to top</a>
      </p>

    </div>

    <?=Site::footer();?>
    <link href="<?=Site::$url;?>/assets/css/genixfont.css" rel="stylesheet">
    <link href="<?=Site::$url;?>/inc/themes/default/css/blog.css" rel="stylesheet">
  </body>
</html>
